<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Finager Blog</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/responsive.css">
</head>

<body>
<style>
	.navbar-default .navbar-nav>li>a {
			color:#fff;
		}
</style>
	<!-- <section id="details_header"></section> -->
	<section id="details_header">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="../index.html">
						<div class="logo">
							<img src="<?php echo base_url();?>resource/blog/images/FinagerWhiteLogo.svg" />
						</div>
					  </a>
					</div>
				
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="#">Home</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">Our team</a></li>
							<li><a href="#">Our portfolio</a></li>
							<li><a href="#">contact</a></li>
							<!-- <button type="button" class="btn btn-default blog_btn">
							  <span class="glyphicon glyphicon-search gis"></span> 
							</button> -->
							<a data-toggle="collapse" href="#search" aria-expanded="false" aria-controls="search">
							  <i class="fa fa-search fa-lg blog_scl" aria-hidden="true" ></i>
							</a>
							<div class="collapse" id="search">        
								<form class="navbar-form">
									<div class="form-group blog_srch">                              
									  <input type="text" class="form-control blog_Sr" placeholder="search here">
									</div>                       
								</form>
							</div>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
			<div class="details_heading_img">
				<img src="<?php echo base_url();?>resource/blog/images/Asef Jamil.jpg" alt="not-found"/>
				<h4>Asef Jamil</h4>
				<h5>Asst. Manager</h5>
				<p>Index Group</p>
				<a href="#">View profile</a>
			</div>
		</div>
	</section>
	<section id="details_highlight">
		<div class="container">
			<div class="details_post">
				<div class="details_heading">
					<h3>Five Years Fixed Deposit Interest Rates </h3>
					<h4><i>Asef Jamil, 02-Oct-2016</i></h4>
				</div><br/>
				<p>
					Fixed deposits offer higher interests than savings accounts and are fairly popular with customers in India. These deposits are usually offered for tenures ranging 
					from 7 days to 10 years. The products are offered in categories such as tax saver fixed deposits, regular fixed deposits, senior citizen fixed deposits etc.
				</p>
				<p>
					Though products vary in categories, the interest rates for particular maturity slabs stay uniform for all categories offered by a single company. For instance,
					a 5 year tax saver deposit and a 5 year regular deposit from a bank will be offered at the same rate of 8.50% p.a. The difference between categories arises in 
					additional benefits from a deposit – a tax saver deposit offers greater tax benefits on the deposit than regular deposits.
				</p><br/>
				<h4><b>5 years fixed deposits</b></h4>
				<p>
					The 5 year fixed deposits denote long term maturities that provide substantial returns on the principal amount. A point to note here is that the 5 years maturity 
					fixed deposits may not be a fixed maturity plan – it will most likely be a part of the maturity slab of 3-5 years or 5-10 years. Similarly, the 5 years fixed 
					deposit interest rates may not be exclusively applicable for the 5 years slab, and will probably be applicable also for a few years in either direction.
				</p>
				<p>
					5 years fixed deposit interest rates vary from company to company. The current rates for this maturity slab lie within 8.00% to 10.00% compounded 
					yearly/half-yearly/quarterly/monthly as per the selected deposit scheme. The rates are directly affected by policy reviews done by the Reserve Bank of India (RBI)
					at regular intervals. Once the RBI announces new rates, banks and other financial institutions are expected to reflect the revised rates on their products.
				</p>
				<br/>
				<h4><b>Interest calculations</b></h4>
				<p>
					Different providers offer different interest rates according to company policy. Also, you may have noticed the interest rates being compounded 
					monthly/quarterly/half-yearly/yearly. In general, a monthly compounded deposit will provide higher returns than the less frequent quarterly, 
					half-yearly and yearly deposits.
				</p>
				<p>
					For instance, the interest on a 5 years fixed deposit compounded annually is 9.25%, while the interest on a 5 years deposit compounded quarterly is 9.00%.
					Let’s assume the deposit value to be Rs.2 lakhs. In this case, the quarterly compounded deposit will give a slightly higher return of Rs.3.12 lakhs at maturity, 
					whereas the yearly compounded deposit will give a return of Rs.3.11 lakhs.
				</p>
				<p>
					As such, you should not get carried away only by looking at high interest rates. It is imperative that you incorporate the frequency of compounding while making calculations of returns from a particular fixed deposit account.
				</p>
				<p>
					Also, high fixed deposit rates offered on a company’s fixed deposit does not necessarily imply a safe and reliable product. If you are investing in a fairly new 
					company’s fixed deposit, avoiding long term deposits is an intelligent choice as small or new companies may not be able to provide quoted returns at maturity. 
					In such a scenario, you might end up losing money from your deposit.
				</p>
			</div>
		</div>	
	</section>	
	<section id="hight_header_post_">
		<div class="container">			
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="relative">
						<p>Comment</p>
						<textarea class="common_textarea form-control" rows="4"></textarea>
					</div>
					<button class="btn common_btn user_comment_btn">Post</button>
				</div>
				
				<div class="col-sm-6 col-xs-12">
					<div class="icon">
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/facebook_counter.png" alt="facebook_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/twitter_counter.png" alt="twitter_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/pinterest_counter.png" alt="pinterest_counter"/></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- <div class="horizantal_bar"></div> -->
	
	<section id="details_related">
		<div class="container">
			<hr/>
			<div class="related_post">
				<h3 class="related_pst">Related Post</h3>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/new car.png" alt="not found"/>
					<h4>Buying a New Car</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Technology has come a long way over the years, taking even shopping for the car you want to a level beyond what it was just a decade ago.
					   These changes can be rather scary. Online search bars and their results can spill mass................
					</p>
					<a href="<?php echo base_url();?>blog/car_loan1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/CreditCard.png" alt="home_moto_blog"/>
					<h4>6 Best Credit Card </h4>
					<h5><i>Writen by Akter, 03-Oct-2016</i></h5>
					<p>At time when the focus many in Nation’s Capital is on youth gangs and violence, 
						historic Metropolitan AME Church in down town will spot light youth who are achieving academically and will display.
					</p>
					<a href="<?php echo base_url();?>resource/blog/credit_card1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/home_moto_blog.jpg" alt="home_moto_blog"/>
					<h4>What is Lorem Ipsum</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
						Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
					</p>
					<a href="#"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>				
			</div>
		</div>
	</section>
<script src="js/jquery-1.11.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>

</script>
</body>
</html>
