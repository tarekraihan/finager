<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Finager Blog</title>
    <script src="<?php echo base_url();?>resource/front_end/js/jquery-1.11.3.js"></script>
    <script src="<?php echo base_url();?>resource/front_end/js/booNavigation.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/ws-calendar.default.min.css" />
     <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/front_end/css/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/style.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/responsive.css">

    <link rel="stylesheet" href="<?php echo base_url();?>resource/blog/css/jquery-ui.css">
</head>

<body>