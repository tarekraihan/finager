<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Finager Blog</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/responsive.css">
</head>

<body>
<style>
	.navbar-default .navbar-nav>li>a {
			color:#fff;
		}
</style>
	<!-- <section id="details_header"></section> -->
	<section id="details_header">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="../index.html">
						<div class="logo">
							<img src="<?php echo base_url();?>resource/blog/images/FinagerWhiteLogo.svg" />
						</div>
					  </a>
					</div>
				
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="#">Home</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">Our team</a></li>
							<li><a href="#">Our portfolio</a></li>
							<li><a href="#">contact</a></li>
							<!-- <button type="button" class="btn btn-default blog_btn">
							  <span class="glyphicon glyphicon-search gis"></span> 
							</button> -->
							<a data-toggle="collapse" href="#search" aria-expanded="false" aria-controls="search">
							  <i class="fa fa-search fa-lg blog_scl" aria-hidden="true" ></i>
							</a>
							<div class="collapse" id="search">        
								<form class="navbar-form">
									<div class="form-group blog_srch">                              
									  <input type="text" class="form-control blog_Sr" placeholder="search here">
									</div>                       
								</form>
							</div>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
			<div class="details_heading_img">
				<img src="<?php echo base_url();?>resource/blog/images/Akter.jpg" alt="not-found"/>
				<h4>Akter ul alam</h4>
				<h5>Head of R&D</h5>
				<p>Index Group</p>
				<a href="#">View profile</a>
			</div>
		</div>
	</section>
	<section id="details_highlight">
		<div class="container">
			<div class="details_post">
				<div class="details_heading">
					<h3>Chip Debit Cards: What You Need to Know</h3>
					<h4><i>Akter ul alam, 02-Oct-2016</i></h4>
				</div>
				<br/>
				<p>
					That little 3" x 2" piece of plastic in your wallet is getting an upgrade. That’s right, your debit card is getting a facelift. Talk about plastic surgery!
				</p>
				<p>
					Honestly, most of us don’t give a lot of thought to how that debit card works on a daily basis. For years, we’ve just swiped the card, typed in our PIN number, and headed home with our stuff.
					Beginning late in 2015, that process started to change. Banks and financial institutions began rolling out the new chip debit cards. These MasterCard and Visa cards look like the ones you’ve used for years—the same numbers, logos, security number on the back and magnetic strip. So what’s new?
				</p><br/>
				<p>
					<b>The real difference with these new cards is the small computer chip embedded in the front just above the first set of numbers</b>. That little metallic microchip 
					allows your card to "talk" to the latest chip-enabled point-of-sale terminals at your favorite stores.
				</p><br/>
				<img src="<?php echo base_url();?>resource/blog/images/emvChip.jpg" alt="EMV CHIP"><br/>
				<h4><b>Why All the Fuss About This Little Chip?</b></h4>	
				<p>
					The standard magnetic strip cards we typically use in the U.S. are based on a 50-year-old technology. The magnetic strip stores your name, account number,
					the card expiration date and the security code from the back of the card. If someone stole your card or even just swiped it through a card reader,
					all of that information could be used for illegal purposes and even full-blown identity theft.
				</p>	
				<p>
					The new EMV chip cards, however, have been used in Europe since 1994 as an attempt to battle the high rates of fraud and counterfeiting. 
					<b>EMV stands for Europay/MasterCard/Visa</b>—these companies have worked together to implement new, more secure technology. The card’s microchip 
					creates a unique one-time-use code for each transaction. This makes the cards more difficult to counterfeit and makes them useless for onsite retail purchases 
					if someone steals your card without knowing your PIN. It also prevents hackers from getting your account number in the event of a store’s data breach.
				</p>
			</div>
		</div>	
	</section>
	<section id="hight_header_post_">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="relative">
						<p>Comment</p>
						<textarea class="common_textarea form-control" rows="4"></textarea>
					</div>
					<button class="btn common_btn user_comment_btn">Post</button>
				</div>
				
				<div class="col-sm-6 col-xs-12">
					<div class="icon">
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/facebook_counter.png" alt="facebook_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/twitter_counter.png" alt="twitter_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/pinterest_counter.png" alt="pinterest_counter"/></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- <div class="horizantal_bar"></div> -->
	
	<section id="details_related">
		<div class="container">
			<hr/>
			<div class="related_post">
				<h3 class="related_pst">Related Post</h3>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/new car.png" alt="not found"/>
					<h4>Buying a New Car</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Technology has come a long way over the years, taking even shopping for the car you want to a level beyond what it was just a decade ago.
					   These changes can be rather scary. Online search bars and their results can spill mass................
					</p>
					<a href="<?php echo base_url();?>blog/car_loan1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-65"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/personal_loan.jpg" alt="home_moto_blog"/>
					<h4>Six Reasons to Get a Personal Loan</h4>
					<h5><i>Writen by Asef Jamil, 10-10-2016</i></h5>
					<p>While it would be great if we all had enough money to fund all of life’s expenses without worry, 
						we know that’s not the case. Sometimes we have to borrow a little to keep............
					</p>
					<a href="<?php echo base_url();?>blog/personal_loan1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/home_moto_blog.jpg" alt="home_moto_blog"/>
					<h4>What is Lorem Ipsum</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
						Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
					</p>
					<a href="#"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>				
			</div>
		</div>
	</section>
<script src="js/jquery-1.11.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>

</script>
</body>
</html>
