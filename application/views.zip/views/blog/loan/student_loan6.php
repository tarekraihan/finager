<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Finager Blog</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>resource/blog/css/responsive.css">
</head>

<body>
<style>
	.navbar-default .navbar-nav>li>a {
			color:#fff;
		}
</style>
	<!-- <section id="details_header"></section> -->
	<section id="details_header">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="../index.html">
						<div class="logo">
							<img src="../images/FinagerWhiteLogo.svg" />
						</div>
					  </a>
					</div>
				
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="#">Home</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">Our team</a></li>
							<li><a href="#">Our portfolio</a></li>
							<li><a href="#">contact</a></li>
							<!-- <button type="button" class="btn btn-default blog_btn">
							  <span class="glyphicon glyphicon-search gis"></span> 
							</button> -->
							<a data-toggle="collapse" href="#search" aria-expanded="false" aria-controls="search">
							  <i class="fa fa-search fa-lg blog_scl" aria-hidden="true" ></i>
							</a>
							<div class="collapse" id="search">        
								<form class="navbar-form">
									<div class="form-group blog_srch">                              
									  <input type="text" class="form-control blog_Sr" placeholder="search here">
									</div>                       
								</form>
							</div>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
			<div class="details_heading_img">
				<img src="<?php echo base_url();?>resource/blog/images/Asef Jamil.jpg" alt="not-found"/>
				<h4>Asef Jamil</h4>
				<h5>Asst. Manager</h5>
				<p>Index Group</p>
				<a href="#">View profile</a>
			</div>
		</div>
	</section>
	<section id="details_highlight">
		<div class="container">
			<div class="details_post">
				<div class="details_heading">
					<h3>Benefits of availing an educational loan for abroad studies</h3>
					<h4><i>Asef Jamil, 02-Oct-2016</i></h4>
				</div><br/>
				<p>
					A weak financial background can come in the way of your dreams and not many get the opportunity to get their hands on a scholarship or Government grants. 
					In this case, availing an Education Loan For Abroad Studies can be a wise alternative.
				</p>
				<p>
					About these ads Due to the vast scope of employment and a prestigious degree, a large number of students these days are opting for higher education. 
					Competition is also one of the reasons why most students are shifting their focus towards foreign universities. When it comes to career growth, international
					education helps generate better prospects and an attractive package. India is a developing country and has some of the best educational institutes, yet, there 
					are foreign universities that meet world standards. The idea of studying abroad seems very interesting, but it also requires a huge amount of capital to opt for
					studying in a different country altogether. But, a weak financial background can come in the way of your dreams and not many get the opportunity to get their hands 
					on a scholarship or Government grants. In this case, availing an Education Loan For Abroad Studies can be a wise alternative. A loan not just takes care of your
					university fees, but also covers a wide range of expenses such as stationery supplies, cost of books and laptop/computer, travel and accommodation, tuition fees, 
					library charges, and much more. Before you avail a loan, here are a few things that you need to keep in mind:
				</p>
				<br/>
				<h4><b>Apply after you have a secure admission</b></h4>
				<p>
					The best time to apply for an education loan is after you have received your admission letter. A loan is approved by the lender only when the borrower has a 
					secure admission in the intended college. Invest some time in researching about the pros and cons of an educational loan.
				</p><br/>
				<h4><b>Put a sufficient amount of time in comparing</b></h4>
				<p>
					When find a loan, it becomes very important to shortlist from a number of options rather than sticking with the first source that comes your way. A bit of comparison
					will let you know who is offering what and ho wit can be better than the other available options in the market. There may be banks that may allure you with their most 
					enticing interest rates, but that should not make you settle for anything less than you deserve. One should not get fooled by exciting claims made by lenders. Instead,
					you should use your analytical skills in figuring out what would best suit your budget and requirements.
				</p>
				<p>
					While conducting your research, you will come across many variations with different interest rates and flexible repayment modes. As far as an education loan is 
					concerned, the repayment, usually starts after you complete your course and in some cases, the lender also offers a grace period of 6 to 12 months in addition to 
					the duration of the course. Various degree as well as diploma courses are covered under an educational loan for abroad studies. Many parents as well prefer borrowing 
					from a state run bank than a private bank. Although, these days, you can find financial institutions that offer affordable interest rates and feasible repayment 
					options. Leading financiers have broken the myth that only Government banks are reliable in availing loans by offering innovative loan schemes to their clients.
				</p>
.			</div>
		</div>	
	</section>	
	<section id="hight_header_post_">
		<div class="container">			
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="relative">
						<p>Comment</p>
						<textarea class="common_textarea form-control" rows="4"></textarea>
					</div>
					<button class="btn common_btn user_comment_btn">Post</button>
				</div>
				
				<div class="col-sm-6 col-xs-12">
					<div class="icon">
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/facebook_counter.png" alt="facebook_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/twitter_counter.png" alt="twitter_counter"/></a>
						<a href="#"><img src="<?php echo base_url();?>resource/blog/images/pinterest_counter.png" alt="pinterest_counter"/></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- <div class="horizantal_bar"></div> -->
	
	<section id="details_related">
		<div class="container">
			<hr/>
			<div class="related_post">
				<h3 class="related_pst">Related Post</h3>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/new car.png" alt="not found"/>
					<h4>Buying a New Car</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Technology has come a long way over the years, taking even shopping for the car you want to a level beyond what it was just a decade ago.
					   These changes can be rather scary. Online search bars and their results can spill mass................
					</p>
					<a href="<?php echo base_url();?>blog/car_loan1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/CreditCard.png" alt="home_moto_blog"/>
					<h4>6 Best Credit Card </h4>
					<h5><i>Writen by Akter, 03-Oct-2016</i></h5>
					<p>At time when the focus many in Nation’s Capital is on youth gangs and violence, 
						historic Metropolitan AME Church in down town will spot light youth who are achieving academically and will display.
					</p>
					<a href="<?php echo base_url();?>blog/credit_card1"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>
				<div class="col-md-4 col-sm-6"> 
					<img class="img-responsive" src="<?php echo base_url();?>resource/blog/images/home_moto_blog.jpg" alt="home_moto_blog"/>
					<h4>What is Lorem Ipsum</h4>
					<h5><i>Writen by Sujat, 03-Oct-2016</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
						Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
					</p>
					<a href="#"><button type="button" class="btn btn-primary details_btn">Read More</button></a>
				</div>				
			</div>
		</div>
	</section>
<script src="js/jquery-1.11.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>

</script>
</body>
</html>
