<style>

</style>
<section id="all_logo">
    <div class="container">
        <div class="row">
            <div class="catagory-icon">
                <h1>All Category Icon</h1>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/all scheme.png" alt=""/>
                            <p>All Scheme</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/business loan.png" alt=""/>
                            <p>Business Loan</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/buy new car.png" alt=""/>
                            <p>Buy New Car</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/credit card.png" alt=""/>
                            <p>Credit Card</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/education loan.png" alt=""/>
                            <p>Education Loan</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/financial calculator.png" alt=""/>
                            <p>Financial Calculator</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/home loan.png" alt=""/>
                            <p>Home Loan</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/loan.png" alt=""/>
                            <p>Loan</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/money market.png" alt=""/>
                            <p>Money Market</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/personal loan.png" alt=""/>
                            <p>Personal Loan</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/bank map.png" alt=""/>
                            <p>Bank Map</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/categoryIcon/more.png" alt=""/>
                            <p>More</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-1-year.png" alt=""/>
                            <p>FDR one year</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-2-Years.png" alt=""/>
                            <p>FDR two year</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-3-months.png" alt=""/>
                            <p>FDR 3 Months</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-3-Years.png" alt=""/>
                            <p>FDR 3 Years</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-4-Years.png" alt=""/>
                            <p>FDR 4 Years</p>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <div class="Cicon">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>resource/front_end/images/fdr-5-Years.png" alt=""/>
                            <p>FDR 5 Years</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>